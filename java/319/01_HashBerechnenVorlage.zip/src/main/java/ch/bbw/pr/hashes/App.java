package ch.bbw.pr.hashes;

import com.google.common.hash.Hashing;

import java.nio.charset.StandardCharsets;

/**
 * Application
 * @author Peter Rutschmann
 * @date 13.12.2022
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Berechne einige Hashes" );

        //TODO hier Passwort eintragen
        String password = "";
        //TODO hier hash von Passwort mit Hilfe von Hashing.sha256 berechnen
        String sha256hex = "";

        System.out.println("Passwort: " + password);
        System.out.println("HashFunction: sha256");
        System.out.println("Hash: " + sha256hex);
        System.out.println();

        //TODO hier hash von Passwort mit Hilfe von Hashing.sha512 berechnen
        String sha512hex = "";

        System.out.println("Passwort: " + password);
        System.out.println("HashFunction: sha512");
        System.out.println("Hash: " + sha512hex);

        //TODO Zusatzaufgabe ausprobieren, welche anderen Hashfunktionen Hashing unterstützt

    }
}

package ch.bbw.af;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

// Aufgabe 13.5.4
public class Main {
    public static void main(String[] args) {

        List<Flugzeuge> flugzeugeList = new ArrayList<>();
        flugzeugeList.add(new Flugzeuge("A380", 509 , Color.white));
        flugzeugeList.add(new Flugzeuge("A319", 231, Color.DARK_GRAY));
        System.out.println(flugzeugeList);

        System.out.println("\nI did it right mister Rutschmann!");
    }
}
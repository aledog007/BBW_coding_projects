package ch.bbw.doitwithstring;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.HashMap;
import java.util.List;

/**
 * ViewController
 *    Kontrolliert Zusammenspiel mit der View.
 *    Regiert auf Aktionen in der View.
 * @author Peter Rutschmann
 * @version 06.12.2021
 */
@Controller
public class ViewController {

    ViewData viewData = new  ViewData();

    @GetMapping("/")
    public String redirect() {
        return "redirect:/convert";
    }

    @GetMapping("/convert")
    public String showView(Model model) {
        model.addAttribute("viewData", viewData);
        return "CodeConvertForm";
    }

    @PostMapping(value = "/convert", params = {"showButton=aufgabe1"})
    public String aufgabe1(Model model, @ModelAttribute("viewData") ViewData viewData) {
        System.out.println("ViewController.aufgabe1: " + viewData);
        System.out.println("ViewController.aufgabe1: " + viewData.getFirstString());  //-> GUI Feld "Erster String"
        System.out.println("ViewController.aufgabe1: " + viewData.getSecondString());  //-> GUI Feld "Zweiter String"
        System.out.println("ViewController.aufgabe1: " + viewData.getThirdString());  //-> GUI Feld "Dritter String"
        System.out.println("ViewController.aufgabe1: " + viewData.getOutput());   //-> GUI Feld "Output"

        // Aufgabe 1
        String ergebnis=viewData.getFirstString() + " -> morse: ";
        /* Hier implementieren Sie die Konvertierung */
        String eingabe= viewData.getFirstString().toLowerCase().trim();
        //das alphabet initzialisieren
        String abc = "abcdefghijklmnopqrstuvwxyz";
        //List mit Morse Code (es initzalisiert in einer liste (String) den Buchstaben und setzt in Morse code um
        List <String> morse = List.of(".-", "-...", ".-","-...","-.-.","-..",".","..-.","--.","....","..",".---","-.-",".-..","--","-.","---",".--.",
                                      "--.-",".-.","...","-","..-","...-",".--","-..-","-.--","--..");
        // geht durch alle buchstaben mit plus 1 bis er den richtigen Buchstaben hat
        for (int i = 0; i < eingabe.length(); i++) {
           //suche index von buchstabe der eingabe durch
           int index = abc.indexOf(eingabe.charAt(i));
           //suche morse-code an index
            String code = morse.get(index);
            ergebnis = ergebnis + code + "/";
        }
        viewData.setOutput(ergebnis);
        model.addAttribute("viewData", viewData);
        return "CodeConvertForm";
    }

    @PostMapping(value = "/convert", params = {"showButton=aufgabe2"})
    public String aufgabe2(Model model, @ModelAttribute("viewData") ViewData viewData) {
        System.out.println("ViewController.aufgabe2");

        // Aufgabe 2
        String ergebnis = viewData.getFirstString() + "  -> text/Char: ";
        //String ergebnis="";
        /* Hier implementieren Sie die Konvertierung */
        String eingabe = viewData.getFirstString().trim();
        // Morsezeichen zu Buchstaben Zuordnung
        HashMap<String, Character> morseToStr = new HashMap<>();
        morseToStr.put(".-", 'A');
        morseToStr.put("-...", 'B');
        morseToStr.put("-.-.", 'C');
        morseToStr.put("-..", 'D');
        morseToStr.put(".", 'E');
        morseToStr.put("..-.", 'F');
        morseToStr.put("--.", 'G');
        morseToStr.put("....", 'H');
        morseToStr.put("..", 'I');
        morseToStr.put(".---", 'J');
        morseToStr.put("-.-", 'K');
        morseToStr.put(".-..", 'L');
        morseToStr.put("--", 'M');
        morseToStr.put("-.", 'N');
        morseToStr.put("---", 'O');
        morseToStr.put(".--.", 'P');
        morseToStr.put("--.-", 'Q');
        morseToStr.put(".-.", 'R');
        morseToStr.put("...", 'S');
        morseToStr.put("-", 'T');
        morseToStr.put("..-", 'U');
        morseToStr.put("...-", 'V');
        morseToStr.put(".--", 'W');
        morseToStr.put("-..-", 'X');
        morseToStr.put("-.--", 'Y');
        morseToStr.put("--..", 'Z');
        //chat gpt anfang
        for (String morse : eingabe.split(" ")) {
            // Überprüfe, ob das Morsezeichen in der HashMap existiert
            if (morseToStr.containsKey(morse)) {
                // Wenn ja, füge den entsprechenden Buchstaben dem Ergebnis hinzu
                ergebnis += morseToStr.get(morse);
            }
            //chatgpt ende
            ergebnis = ergebnis + " /";
        }
        viewData.setOutput(ergebnis);
        model.addAttribute("viewData", viewData);
        return "CodeConvertForm";
    }

    @PostMapping(value = "/convert", params = {"showButton=aufgabe3"})
    public String aufgabe3(Model model, @ModelAttribute("viewData") ViewData viewData) {
        System.out.println("ViewController.aufgabe3");

        //Aufgabe 3
        //String ergebnis = <ergänzen>

        //Ergebnis an GUI Daten übergebend
        //viewData.setOutput(ergebnis);

        model.addAttribute("viewData", viewData);
        return "CodeConvertForm";
    }

    @PostMapping(value = "/convert", params = {"showButton=aufgabe4"})
    public String aufgabe4(Model model, @ModelAttribute("viewData") ViewData viewData) {
        System.out.println("ViewController.aufgabe4");

        //Aufgabe 4

        model.addAttribute("viewData", viewData);
        return "CodeConvertForm";
    }

    @PostMapping(value = "/convert", params = {"showButton=aufgabe5"})
    public String aufgabe5(Model model, @ModelAttribute("viewData") ViewData viewData) {
        System.out.println("ViewController.aufgabe5");

        //Aufgabe 5

        model.addAttribute("viewData", viewData);
        return "CodeConvertForm";
    }

    @PostMapping(value = "/convert", params = {"showButton=aufgabe6"})
    public String aufgabe6(Model model, @ModelAttribute("viewData") ViewData viewData) {
        System.out.println("ViewController.aufgabe6");

        //Aufgabe 6

        model.addAttribute("viewData", viewData);
        return "CodeConvertForm";
    }

    @PostMapping(value = "/convert", params = {"showButton=aufgabe7"})
    public String aufgabe7(Model model, @ModelAttribute("viewData") ViewData viewData) {
        System.out.println("ViewController.aufgabe7");

        //Aufgabe 7

        model.addAttribute("viewData", viewData);
        return "CodeConvertForm";
    }

    @PostMapping(value = "/convert", params = {"showButton=resetView"})
    public String resetView(Model model) {
        viewData = new ViewData();
        model.addAttribute("viewData", viewData);
        return "CodeConvertForm";
    }
}
